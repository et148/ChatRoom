package main;
import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
import org.jvnet.substance.SubstanceLookAndFeel;
import javax.swing.UIManager;
import javax.swing.*;
import app.Server;
public class Main {
    public static void main(String[] args) throws Exception{
    	try
        {
    		BeautyEyeLNFHelper.frameBorderStyle = BeautyEyeLNFHelper.FrameBorderStyle.osLookAndFeelDecorated;
            org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
        }
        catch(Exception e)
        {
            //TODO exception
        }
    	Server server=new Server();
    	
    }
}
