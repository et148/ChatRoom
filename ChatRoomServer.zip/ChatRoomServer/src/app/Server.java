package app;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.Vector;
import javax.swing.*;
import vo.Customer;
import vo.GroupChat;
public class Server extends JFrame implements Runnable{
     /* 客户端连接 */
	private Socket socket=null;
	/* 服务器端接收连接 */
	private ServerSocket serverSocket =null;
	/* 保存客户端的线程 */
	private Vector<ChatThread>clients=new Vector<ChatThread>();
	/* 保存在线用户 */
	//private Vector<ChatThread>groupClient=new Vector<ChatThread>();
	private Vector<GroupChat>group=new Vector<GroupChat>();
	private Vector<Customer>userList=new Vector<Customer>();
	private JLabel lbClient=new JLabel("在线用户");
	public List lstClient=new List();
	private JLabel lbMessage=new JLabel("系统消息");
	private JTextArea taMessage=new JTextArea();
	private JScrollPane spMessage=new JScrollPane(taMessage);
	public JTextField tf=new JTextField(10);
	private JButton jbt=new JButton("关闭服务器");
	public JButton CloseClient=new JButton("关闭该用户");
	public JButton SendMessage=new JButton("发送");
	private JPanel plClient=new JPanel(new BorderLayout());
	private JPanel plMsg=new JPanel(new BorderLayout());
	private JPanel plButton=new JPanel(new GridLayout(1,3));
	private JPanel plClient_Msg=new JPanel(new GridLayout(2,1));
	private JPanel plButton_tf=new JPanel(new GridLayout(2,1));
	private boolean canRun=true;
	public Server()throws Exception{
		this.setTitle("服务器端");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//this.add(jbt,BorderLayout.NORTH);
		plClient.add(lbClient,BorderLayout.NORTH);
		plClient.add(lstClient, BorderLayout.CENTER);
		plMsg.add(lbMessage, BorderLayout.NORTH);
		plMsg.add(spMessage, BorderLayout.CENTER);
		plButton.add(CloseClient);
		plButton.add(SendMessage);
		plButton.add(jbt);
		plClient_Msg.add(plClient);
		plClient_Msg.add(plMsg);
		plButton_tf.add(tf);
		plButton_tf.add(plButton);
		
		this.add(plClient_Msg,BorderLayout.CENTER);
		this.add(plButton_tf, BorderLayout.SOUTH);
	   
		jbt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});	
		this.setBackground(Color.YELLOW);
		this.setSize(400, 300);
		this.setVisible(true);
		/* 服务器端开辟端口，接收连接 */
		serverSocket =new ServerSocket(9999);
		/* 接收客户端连接的循环开始运行 */
		new Thread(this).start();
	}
	public void run() {
		try {
			while(canRun) {
				socket=serverSocket.accept();
				ChatThread ct=new ChatThread(socket,this);
				/* 线程开始运行 */
				SendMessage.addActionListener(ct);
				CloseClient.addActionListener(ct);
			    tf.addActionListener(ct);			    
				ct.start();
				System.out.println("a");
			}
		}catch(Exception ex) {
			canRun=false;
			try {
				serverSocket.close();
			}catch(Exception e) {}
		}
	}
	
	public Vector<ChatThread> getClients(){
		return clients;
	}
	public Vector<Customer> getUserList(){
		return userList;
	}
	
	public void addClient(String msg) {
		lstClient.add(msg);
	}
	public void decClient(String msg) {
		lstClient.remove(msg);
	}
	public String getMsg() {
		String s=tf.getText();
		return s;
	}
	public void clearTfMsg() {
		tf.setText("");
	}
	public String getSelectedClient() {
		String users=lstClient.getSelectedItem();
		return users.split(",")[0];
	}
	public int getClientNumber() {
		int a=lstClient.getItemCount();
		return a;
	}
	public Vector<GroupChat> getGroup(){
		return group;
	}
	public void setTaMsg(String s) {
		taMessage.append(s);
	}
}
