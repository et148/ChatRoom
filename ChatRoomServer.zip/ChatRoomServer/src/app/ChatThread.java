package app;
import java.util.Vector;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import util.Conf;
import util.FileOpe;
import vo.Customer;
import vo.Message;
import java.awt.event.*;
import vo.GroupChat;
public class ChatThread extends Thread implements ActionListener{
       private Socket socket=null;
       private ObjectInputStream ois=null;
       private ObjectOutputStream oos=null;
       private Customer customer=null;
       private Server server=null;
       private boolean canRun=true;
       public static int c=0;
       public ChatThread(Socket socket,Server server) throws Exception{
    	   this.socket=socket;
    	   this.server=server;
    	   oos=new ObjectOutputStream(socket.getOutputStream());
    	   ois=new ObjectInputStream(socket.getInputStream());
       }
       public void run() {
    	   try {
    		   while(canRun) {  			   
    			   Message msg=(Message)ois.readObject();
    			   /*分析之后转发*/
    			   String type=msg.getType();
    			   System.out.println(type);
    			   if(type.equals(Conf.LOGIN)) {
    				   this.handleLogin(msg);//处理登录信息
    			   }else if(type.equals(Conf.REGISTER)) {
    				   this.handleRegister(msg);//处理注册信息
    			   }else if(type.equals(Conf.MESSAGE)) {
    				   this.handleMessage(msg);//处理发送的信息
    			   }else if(type.equals(Conf.CREATEGROUP)) {//处理建群消息
    				   this.handleCreateGroup((String)msg.getContent(),msg.getFrom());
    			   }else if(type.equals(Conf.JOINGROUP)) {//处理加入群聊信息
    				   this.handleJoinGroup((String)msg.getContent(),msg.getFrom());
    			   }else if(type.equals(Conf.GROUPMESSAGE)) {//处理群消息
    				   this.handleGroupMessage(msg);
    			   }
    		   }
    	   }catch(Exception ex) {
    		   this.handleLogout();
    		  // ex.printStackTrace();
    	   }
       }
       /*******************处理登录信息***************/
       public void handleLogin(Message msg) throws Exception{
    	   Customer loginCustomer=(Customer)msg.getContent();
    	   String account=loginCustomer.getAccount();
    	   String password=loginCustomer.getPassword();
    	  // String nickName=loginCustomer.getNickName();
    	   Customer cus=FileOpe.getCustomerByAccount(account);
    	   Message newMsg=new Message();
    	   if(cus==null||!cus.getPassword().equals(password)) {
    		   newMsg.setType(Conf.LOGINFALL);
    		   oos.writeObject(newMsg);
    		   canRun=false;
    		   socket.close();
    		   return;
    	   }
    	   this.customer=cus;
    	 /**将该线程放入clients集合**/
    	  server.getClients().add(this);
    	  /* 将customer加入到userList中 */
    	  server.getUserList().add(this.customer);
    	  server.addClient(this.customer.getAccount()+","+this.customer.getNickName());
    	  /* 注意，应该是将所有的在线用户都要转发给客户端 */
    	  newMsg.setType(Conf.USERLIST);
    	  newMsg.setContent(server.getUserList().clone());
    	  /* 将该用户登录的信息发给所有用户 */
    	  this.sendMessage(newMsg,Conf.ALL);
    	  server.setTitle("当前在线："+server.getClients().size()+"人");
    	  
       }
       /**********************将msg里的内容以聊天信息形式转发****************************/
       public  void handleRegister(Message msg)throws Exception{
    	   Customer registerCustomer =(Customer)msg.getContent();
    	   String account=registerCustomer.getAccount();
    	   Customer cus=FileOpe.getCustomerByAccount(account);
    	   Message newMsg=new Message();
    	   if(cus!=null) {
    		   newMsg.setType(Conf.REGISTERFALL);
    	   }else {
    		   String password=registerCustomer.getPassword();
    		   String nickName=registerCustomer.getNickName();
    		   FileOpe.insertCustomer(account, password, nickName);
    		   newMsg.setType(Conf.REGISTERSUCCESS);
    		   oos.writeObject(newMsg);         //发给注册用户
    	   }
    	   oos.writeObject(newMsg);             //发给注册用户
    	   canRun=false;
    	   socket.close();   			
       }
       /**********************将msg里的内容以聊天信息形式转发****************************/
       public void handleMessage(Message msg)throws Exception{
    	   String to=msg.getTo();
    	   sendMessage(msg,to);
       }
       /******************向所有其他客户端发送一个该客户端下线的信息***********************/
       public void handleLogout() {
    	   Message logoutMessage=new Message();
    	   logoutMessage.setType(Conf.LOGOUT);
    	   logoutMessage.setContent(this.customer);
    	   server.getClients().remove(this);            //将自己从clients中去掉
    	   server.getUserList().remove(this.customer);
    	   try {
    		   sendMessage(logoutMessage,Conf.ALL);
    		   canRun=false;
    		   socket.close();
    	   }catch(Exception ex) {
    		   ex.printStackTrace();
    	   }
    	   server.decClient(this.customer.getAccount()+","+this.customer.getNickName());
    	   server.setTitle("当前在线："+server.getClients().size()+"人");
    	   for(GroupChat gc:server.getGroup()) {         //从群组中去掉
    		   if(gc.getMember().contains(this.customer.getAccount())) {
    			   gc.getMember().remove(this.customer.getAccount());
    		   }
    	   }
       }
       /*****************将信息发给某个客户端***********************/
       public void sendMessage(Message msg,String to) throws Exception{
    	   for(ChatThread ct:server.getClients()) {
    		   if(ct.customer.getAccount().equals(to)||to.equals(Conf.ALL)) {
    			   ct.oos.writeObject(msg);
    		   }
    	   }
       }
     
       public void actionPerformed(ActionEvent e) {
    	   if(e.getSource()==server.SendMessage) {
    		   c++;
    		   Message msg=new Message();
    		   msg.setType(Conf.SERVERMSG);
    		   String mess = server.getMsg();
    		   msg.setContent(mess);
    		   if(c==1) {
        	      server.setTaMsg("服务器："+mess);   
    		   }
    		   try{
                    this.oos.writeObject(msg);
    		   }catch(Exception ex) {}
    		   if(c==server.getClients().size()) {
    			   server.clearTfMsg();
    			   c=0;
    		   }
    		   
    	   }else if(e.getSource()==server.CloseClient) {
    		   Message msg=new Message();
    		   msg.setType(Conf.SERVEROUT);
    		   try {
        		   sendMessage(msg,server.getSelectedClient());
    		   }catch(Exception e2) {}
    	   }
       }
       public void handleCreateGroup(String groupName,String from) throws Exception{
    	   GroupChat gc=new GroupChat(groupName);
    	   server.getGroup().addElement(gc);
  //  	   gc.getMember().add(from);  函数用错了，不是add，返回bool值
    	   gc.getMember().addElement(from);
    	   Message msg=new Message();
		   msg.setType(Conf.CREATEGROUPSUCCESS);
		   msg.setContent(groupName);
		   this.oos.writeObject(msg);  	   
       }
       public void handleJoinGroup(String groupName,String from) throws Exception{
    	   int count=0;
    	   for(GroupChat gc:server.getGroup()) {
    		   if(gc.getGroupName().equals(groupName)) {
    			   gc.getMember().addElement(from);
    			   Message msg=new Message();
    			   msg.setType(Conf.JOINGROUPSUCCESS);
    			   msg.setContent(groupName);
    			   this.oos.writeObject(msg);
    			   count=1;
    		   }
    	   }
    	  if(count==0) {
    		  Message msg=new Message();
			  msg.setType(Conf.JOINGROUPFALL);
			  this.oos.writeObject(msg);
    	  }
       }
       public void handleGroupMessage(Message msg) throws Exception{
    	   String groupName=msg.getTo();
    	   System.out.println("gropu");
    	   for(GroupChat gc:server.getGroup()) {
    		   if(gc.getGroupName().equals(groupName)) {
    			   for(String s:gc.getMember()) {
    				  Message msg2=new Message();
    				  msg2.setFrom(msg.getFrom());
    				  msg2.setType(Conf.GROUPMESSAGE);
    				  msg2.setContent("群"+groupName+"中"+msg.getContent());
    				  msg2.setTo(s);
    				  sendMessage(msg2,s);
    				  System.out.println("gropu");
    			   }
    		   }
    	   }
       }
}
