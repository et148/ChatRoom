package vo;
import java.io.Serializable;

/***********************封装顾客信息的类********************/

public class Customer implements Serializable{
      private String account;
      private String password;
      private String nickName;
      public String getAccount() {
    	  return this.account;
      }
      public void setAccount(String account) {
    	  this.account=account;
      }
      public String getPassword() {
    	  return this.password;
      }
      public void setPassword(String password) {
    	  this.password=password;
      }
      public String getNickName() {
    	  return this.nickName;
      }
      public void setNickName(String nickName) {
    	  this.nickName=nickName;
      }
      public String toString() {
    	  return account+"#"+password+"#"+nickName;
      }
}
