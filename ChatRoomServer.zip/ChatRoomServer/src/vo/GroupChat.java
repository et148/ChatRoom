package vo;
import java.util.Vector;
public class GroupChat {
	 String groupName;
	 Vector <String> member=new Vector<String>();
     public GroupChat(String groupName) {
    	 this.groupName=groupName;
     }
//     public Vector<ChatThread> getMember(){
//    	 return member;
//     }
     public Vector<String>getMember(){
    	 return member;
     }
     public String getGroupName() {
    	 return groupName;
     }
}
