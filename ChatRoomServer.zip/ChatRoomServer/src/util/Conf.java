package util;

public class Conf {
     public static final String LOGIN="LOGIN";                          //登录
     public static final String REGISTER="REGISTER";                    //注册
     public static final String LOGINFALL="LOGINFALL";                  //登录失败
     public static final String USERLIST="USERLIST";                    //用户名单，登录成功
     public static final String REGISTERSUCCESS="REGISTERSUCCESS";      //注册成功
     public static final String REGISTERFALL="REGISTERFALL";            //注册失败
     public static final String MESSAGE="MESSAGE";                      //普通聊天信息
     public static final String LOGOUT="LOGOUT";                        //退出
     public static final String ALL="ALL";                              //所有人
     public static final String SERVERMSG="SERVERMSG";                   //服务器消息
     public static final String SERVEROUT="SERVEROUT";                   //服务器强制下线
     public static final String CREATEGROUP="CREATEGROUP";               //创建群聊
     public static final String JOINGROUP="JOINGROUP";                   //加入群聊
     public static final String CREATEGROUPSUCCESS="CREATEGROUPSUCCESS"; //创建群成功
     public static final String CREATEGROUPFALL="CREATEGROUPFALL";       //创建群失败
     public static final String JOINGROUPSUCCESS="JOINGROUPSUCCESS";     //加入群成功
     public static final String JOINGROUPFALL="JOINGROUPFALL";           //加入群失败
     public static final String GROUPMESSAGE="GROUPMESSAGE";             //群消息
}
