package app;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.*;
import main.Main;
import util.Conf;
import util.GUIUtil;
import vo.Customer;
import vo.Message;
public class RegisterFrame extends JFrame implements ActionListener{
	/***************************定义各控件************************/
	private JLabel lbAccount=new JLabel("请您输入账号");
	private JTextField tfAccount=new JTextField(10);
	private JLabel lbPassword1=new JLabel("请您输入密码");
	private JPasswordField pfPassword1=new JPasswordField(10);
	private JLabel lbPassword2=new JLabel("输入确认密码");
	private JPasswordField pfPassword2=new JPasswordField(10);
	private JLabel lbNickName=new JLabel("请您输入昵称");
	private JTextField tfNickName=new JTextField(10);
	private JButton btRegister=new JButton("注册");
	private JButton btLogin=new JButton("登录");
	private JButton btExit=new JButton("退出");
	private Socket socket=null;
	private ObjectInputStream ois=null;
	private ObjectOutputStream oos=null;
	public RegisterFrame() {
	/**************************界面初始化*************************/
	super("注册");
	this.setLayout(null);
	this.add(lbAccount);
	this.add(tfAccount);
	this.add(lbPassword1);
	this.add(pfPassword1);
	this.add(lbPassword2);
	this.add(pfPassword2);
	this.add(lbNickName);
	this.add(tfNickName);
	this.add(btRegister);
	this.add(btLogin);
	this.add(btExit);
	this.setSize(240, 220);
	GUIUtil.toCenter(this);
	lbAccount.setLocation(20, 20);
	lbAccount.setSize(100, 20);
	tfAccount.setLocation(100, 20);
	tfAccount.setSize(120, 20);
	lbPassword1.setLocation(20, 50);
	lbPassword1.setSize(100, 20);
	pfPassword1.setLocation(100, 50);
	pfPassword1.setSize(120, 20);
	lbPassword2.setLocation(20, 80);
	lbPassword2.setSize(100, 20);
	pfPassword2.setLocation(100, 80);
	pfPassword2.setSize(120, 20);
	lbNickName.setLocation(20, 110);
	lbNickName.setSize(100, 20);
	tfNickName.setLocation(100, 110);
	tfNickName.setSize(120, 20);
	btRegister.setLocation(30, 150);
	btRegister.setSize(50, 20);
	btLogin.setLocation(90, 150);
	btLogin.setSize(50,20);
	btExit.setLocation(150, 150);
	btExit.setSize(50, 20);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setResizable(false);
	this.setVisible(true);
	/*************************增加监听****************************/
	btLogin.addActionListener(this);
	btRegister.addActionListener(this);
	btExit.addActionListener(this);
	}
	public void register() {
		Customer cus=new Customer();
		cus.setAccount(tfAccount.getText());
		cus.setPassword(new String(pfPassword1.getPassword()));
		cus.setNickName(tfNickName.getText());
		Message msg=new Message();
		msg.setType(Conf.REGISTER);
		msg.setContent(cus);
		try {
	//		socket=new Socket(Main.serverIP,Main.port);
			socket=new Socket("127.0.0.1",9999);
			//以下两句有顺序要求
			oos=new ObjectOutputStream(socket.getOutputStream());
			ois=new ObjectInputStream(socket.getInputStream());
			Message receiveMsg=null;
			oos.writeObject(msg);
			receiveMsg=(Message)ois.readObject();
			String type=receiveMsg.getType();
			if(type.equals(Conf.REGISTERFALL)) {
				JOptionPane.showMessageDialog(this, "注册失败");
			}else {
				JOptionPane.showMessageDialog(this, "注册成功");
			}
			socket.close();
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(this, "网络连接异常");
			System.exit(-1);
		}
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btRegister) {
			String password1=new String(pfPassword1.getPassword());
			String password2=new String(pfPassword2.getPassword());
			if(!password1.equals(password2)) {
				JOptionPane.showMessageDialog(this, "两个密码不相同");
				return;
			}
			//连接到服务器并发送注册信息
			this.register();
		}else if(e.getSource()==btLogin) {
			this.dispose();
			new LoginFrame();
		}else {
			JOptionPane.showMessageDialog(this, "谢谢光临");
			System.exit(0);
		}
	}
}
