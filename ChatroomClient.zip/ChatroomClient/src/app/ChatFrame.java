package app;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.color.*;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Vector;
import javax.swing.*;
import util.Conf;
import vo.Message;
import vo.Customer;
public class ChatFrame extends JFrame implements ActionListener,Runnable{
      /*******************定义各控件********************/
	private Socket socket=null;
	private ObjectInputStream ois=null;
	private ObjectOutputStream oos=null;
	private boolean canRun=true;
	private String account;
	private JLabel lbUser=new JLabel("在线人员名单：");
	private List lstUser=new List();
	private JLabel lbMsg=new JLabel("聊天记录：");
	private JTextArea taMsg=new JTextArea();
	private JScrollPane spMsg=new JScrollPane(taMsg);
	private JLabel lbGroup=new JLabel("加入的群");
	private List lstGroup=new List();
	private JTextField tfMsg=new JTextField();
	private JButton btCreateGroup=new JButton("创建群聊");
	private JButton btJoinGroup=new JButton("加入群聊");
	private JButton btSend=new JButton("发送");
	private JButton btSendGroupMsg=new JButton("发送群消息");
	private JPanel plUser=new JPanel(new BorderLayout());
	private JPanel plMsg=new JPanel(new BorderLayout());
	private JPanel plGroup=new JPanel(new BorderLayout());
	private JPanel plUser_Group=new JPanel(new GridLayout(2,1));
	private JPanel plUser_Group_Msg=new JPanel(new GridLayout(1,2));
	private JPanel plSend=new JPanel(new GridLayout(1,4));
	private JPanel plSend_Msg=new JPanel(new BorderLayout());
	public ChatFrame(ObjectInputStream ois,ObjectOutputStream oos,Message receiveMessage,String account) {
		this.ois=ois;
		this.oos=oos;
		this.account=account;
		this.initFrame();
		this.initUserList(receiveMessage);
		new Thread(this).start();
	}
	public void initFrame() {
		this.setTitle("当前在线："+account);
		this.setBackground(Color.magenta);
		plUser.add(lbUser, BorderLayout.NORTH);
		plUser.add(lstUser,BorderLayout.CENTER);
		plUser_Group.add(plUser);
//		lstUser.setBackground(Color.PINK);
		
		plGroup.add(lbGroup,BorderLayout.NORTH);
		plGroup.add(lstGroup, BorderLayout.CENTER);
		plUser_Group.add(plGroup);
//		lstGroup.setBackground(Color.gray);
		
		plMsg.add(lbMsg, BorderLayout.NORTH);
		plMsg.add(spMsg, BorderLayout.CENTER);
		plUser_Group_Msg.add(plUser_Group);
		plUser_Group_Msg.add(plMsg);
//		taMsg.setBackground(Color.pink);
		
		plSend.add(btCreateGroup);
		plSend.add(btJoinGroup);
		plSend.add(btSend);
		plSend.add(btSendGroupMsg);
		
		plSend_Msg.add(tfMsg,BorderLayout.SOUTH);
		plSend_Msg.add(plSend,BorderLayout.NORTH);
//		tfMsg.setBackground(Color.yellow);

		this.add(plUser_Group_Msg,BorderLayout.CENTER);		
		this.add(plSend_Msg, BorderLayout.SOUTH);
		
		btSend.addActionListener(this);
		btCreateGroup.addActionListener(this);
		btJoinGroup.addActionListener(this);
		btSendGroupMsg.addActionListener(this);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500, 500);
		this.setVisible(true);
	}
	public void initUserList(Message message) {
		lstUser.removeAll();
		lstUser.add(Conf.ALL);
		lstUser.select(0);
		Vector<Customer>userListVector=(Vector<Customer>)message.getContent();
		for(Customer cus:userListVector) {
			lstUser.add(cus.getAccount()+","+cus.getNickName());
		}
	}
	public void run() {
		try {
			while(canRun) {
				Message msg=(Message)ois.readObject();
				if(msg.getType().equals(Conf.MESSAGE)) {
					//在ChatFrame的ta内添加内容
					taMsg.append(msg.getContent()+"\n");
				}else if(msg.getType().equals(Conf.USERLIST)) {
					this.initUserList(msg);
				}else if(msg.getType().equals(Conf.LOGOUT)) {
					Customer cus=(Customer)msg.getContent();
					lstUser.remove(cus.getAccount()+","+cus.getNickName());
				}else if(msg.getType().equals(Conf.SERVEROUT)) {
					canRun=false;
					javax.swing.JOptionPane.showMessageDialog(this, "服务器要求您下线");
					System.exit(-1);
				}else if(msg.getType().equals(Conf.SERVERMSG)) {
					taMsg.append("服务器说："+msg.getContent()+"\n");
				}else if(msg.getType().equals(Conf.CREATEGROUPSUCCESS)) {
					lstGroup.add((String)msg.getContent());
				}else if(msg.getType().equals(Conf.CREATEGROUPFALL)) {
					javax.swing.JOptionPane.showMessageDialog(this, "创建失败");
				}else if(msg.getType().equals(Conf.JOINGROUPSUCCESS)) {
					lstGroup.add((String)msg.getContent());
				}else if(msg.getType().equals(Conf.JOINGROUPFALL)) {
					javax.swing.JOptionPane.showMessageDialog(this, "没有该群");
				}else if(msg.getType().equals(Conf.GROUPMESSAGE)) {
					taMsg.append(msg.getContent()+"\n");
				}
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			canRun=false;
			javax.swing.JOptionPane.showMessageDialog(this, "对不起，请您下线");
			System.exit(-1);
		}
	}
	public void actionPerformed(ActionEvent e) {
		try {
			if(e.getSource()==btSend) {
				Message msg=new Message();
				msg.setType(Conf.MESSAGE);
				msg.setContent(account+"说："+tfMsg.getText());
				msg.setFrom(account);
				String toInfo=lstUser.getSelectedItem();
				msg.setTo(toInfo.split(",")[0]);
				oos.writeObject(msg);
				taMsg.append("我说:"+tfMsg.getText()+"\n");
				tfMsg.setText("");
			}else if(e.getSource()==btCreateGroup) {
				String groupName=JOptionPane.showInputDialog("输入要创建群名");
				Message msg=new Message();//创建群
				msg.setType(Conf.CREATEGROUP);
				msg.setContent(groupName);
				msg.setFrom(account);
				oos.writeObject(msg);				
			}else if(e.getSource()==btJoinGroup){
				String groupName=JOptionPane.showInputDialog("输入要加入的群名");
				Message msg=new Message();
				msg.setType(Conf.JOINGROUP);
				msg.setFrom(account);
				msg.setContent(groupName);
				oos.writeObject(msg);
			}else if(e.getSource()==btSendGroupMsg) {
				Message msg=new Message();
				msg.setType(Conf.GROUPMESSAGE);
				msg.setContent(account+"说："+tfMsg.getText());
				msg.setFrom(account);
				msg.setTo(lstGroup.getSelectedItem());				
				oos.writeObject(msg);
				//taMsg.append("我说:"+tfMsg.getText()+"\n");
				tfMsg.setText("");
			}			
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(this, "消息发送异常");
		}
	}
}
