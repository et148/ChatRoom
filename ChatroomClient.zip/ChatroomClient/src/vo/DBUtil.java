package vo;
import java.sql.*;
public class DBUtil {
	private static String driver = null;
	   private static String url = null;
	   private static String username = null;
	   private static String password = null;
	   static {
		   try {
			   driver = "oracle.jdbc.driver.OracleDriver";
			   url = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
			   username = "system";
			   password = "52015189969278";
			   Class.forName(driver);
		   }catch(Exception e) {
			   throw new RuntimeException(e);
		   }
	   }
	   public static Connection getConnection() {
		   try {
			   return DriverManager.getConnection(url, username, password);
		   }catch(SQLException e) {
			   throw new RuntimeException(e);
		   }
	   }
	   
	   public static void close(Connection connection,PreparedStatement pstamt,ResultSet rs) {
		   if(rs!=null) {
			   try {
				   rs.close();
			   }catch(SQLException e) {
				   throw new RuntimeException(e);
			   }
		   }
		   if(pstamt!=null) {
			   try {
				   pstamt.close();
			   }catch(SQLException e) {
				   throw new RuntimeException(e);
			   }
		   }
		   if(connection!=null) {
			   try {
				   connection.close();
			   }catch(SQLException e) {
				   throw new RuntimeException(e);
			   }
		   }	   
	   }
}
