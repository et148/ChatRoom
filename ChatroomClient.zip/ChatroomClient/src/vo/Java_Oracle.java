package vo;

public class Java_Oracle {

}
