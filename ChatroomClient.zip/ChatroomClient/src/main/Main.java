package main;
import java.io.FileReader;
import java.util.Properties;

import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;

import app.LoginFrame;
import app.ChatFrame;
public class Main {
   //  public static String serverIP;
   //  public static int port;
     private static void loadConf()throws Exception{
    	 Properties pps=new Properties();
    	 pps.load(new FileReader("net.conf"));
    //	 serverIP=pps.getProperty("serverIP");
    //	 port = Integer.parseInt(pps.getProperty("port"));
     }
     public static void main(String[] args) throws Exception{
    	 loadConf();  	 
    	 try
         {
     		BeautyEyeLNFHelper.frameBorderStyle = BeautyEyeLNFHelper.FrameBorderStyle.osLookAndFeelDecorated;
             org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
         }
         catch(Exception e)
         {
             //TODO exception
         }
    	// new LoginFrame();
    	 new LoginFrame();
     }
}
